<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class Post
{

}