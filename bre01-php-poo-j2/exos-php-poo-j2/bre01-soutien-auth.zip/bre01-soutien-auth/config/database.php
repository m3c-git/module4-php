<?php

// ici je dois initialiser la connexion à ma base de données