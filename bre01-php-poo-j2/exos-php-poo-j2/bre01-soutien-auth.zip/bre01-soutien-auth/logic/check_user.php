<?php

// Ici je dois vérifier si mon utilisateur est connecté et si il a le rôle user

// s'il n'est pas connecté : redirection vers la home

// s'il est connecté mais qu'il a le rôle admin : redirection vers l'admin

// si il est connecté et qu'il a le role user c'est bon je ne fais rien