<?php

// j'appelle la connexion à ma base de données

// je récupère les informations du formulaire

// je chiffre son mot de passe

// je stocke mon utilisateur avec son mot de passe chiffré dans la base de données

// je modifie ma session pour dire que j'ai un utilisateur connecté et son rôle

// s'il a le role user je redirige vers le profil

// s'il a le role admin je redirige vers l'admin