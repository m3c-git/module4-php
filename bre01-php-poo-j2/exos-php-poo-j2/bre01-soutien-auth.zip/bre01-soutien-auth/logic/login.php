<?php
// j'appelle la connexion à ma base de données

// Ici je vais enter de connecter mon utilisateur

// Je récupère l'email et le password envoyés par le formulaire

// Je vérifie dans la base de données si un utilisateur existe avec cet email

// s'il n'existe pas je redirige vers la home

// si il existe je vérifie si le mot de passe est le bon

// s'il n'est pas bon je redirige vers la home

// s'il est bon je modifie ma session pour dire que j'ai un utilisateur connecté et son rôle

// s'il a le role user je redirige vers le profil

// s'il a le role admin je redirige vers l'admin

