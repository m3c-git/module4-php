<?php

// Ici je dois vérifier si mon utilisateur est connecté et si il a le rôle admin

// s'il n'est pas connecté : redirection vers la home

// s'il est connecté mais a le rôle user : redirection vers le profil

// si il est connecté et qu'il a le role admin c'est bon je ne fais rien