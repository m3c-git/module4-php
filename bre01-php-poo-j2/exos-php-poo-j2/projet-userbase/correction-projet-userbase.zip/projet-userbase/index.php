<?php

require_once "models/User.class.php";
require_once "managers/UserManager.class.php";

require "templates/layout.phtml";