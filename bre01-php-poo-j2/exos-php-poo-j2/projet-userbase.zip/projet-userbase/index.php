<?php

require "templates/layout.phtml";