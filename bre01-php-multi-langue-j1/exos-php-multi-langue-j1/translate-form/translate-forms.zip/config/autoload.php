<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */

require "services/Translator.php";
require "controllers/AbstractController.php";
require "controllers/AuthController.php";
require "services/Router.php";

