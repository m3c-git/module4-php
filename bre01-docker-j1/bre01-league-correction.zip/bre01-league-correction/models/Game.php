<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class Game
{
    private ? int $id = null;

    public function __construct(private string $name, private DateTime $date, private Team $team1, private Team $team2, private Team $winner)
    {

    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @param int|null $id
     */
    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return DateTime
     */
    public function getDate(): DateTime
    {
        return $this->date;
    }

    /**
     * @param DateTime $date
     */
    public function setDate(DateTime $date): void
    {
        $this->date = $date;
    }

    /**
     * @return Team
     */
    public function getTeam1(): Team
    {
        return $this->team1;
    }

    /**
     * @param Team $team1
     */
    public function setTeam1(Team $team1): void
    {
        $this->team1 = $team1;
    }

    /**
     * @return Team
     */
    public function getTeam2(): Team
    {
        return $this->team2;
    }

    /**
     * @param Team $team2
     */
    public function setTeam2(Team $team2): void
    {
        $this->team2 = $team2;
    }

    /**
     * @return Team
     */
    public function getWinner(): Team
    {
        return $this->winner;
    }

    /**
     * @param Team $winner
     */
    public function setWinner(Team $winner): void
    {
        $this->winner = $winner;
    }
}