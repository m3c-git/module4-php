<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class Player
{
    private ? int $id = null;

    public function __construct(private string $nickname, private string $bio, private Media $portrait, private Team $team)
    {

    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @param int|null $id
     */
    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getNickname(): string
    {
        return $this->nickname;
    }

    /**
     * @param string $nickname
     */
    public function setNickname(string $nickname): void
    {
        $this->nickname = $nickname;
    }

    /**
     * @return string
     */
    public function getBio(): string
    {
        return $this->bio;
    }

    /**
     * @param string $bio
     */
    public function setBio(string $bio): void
    {
        $this->bio = $bio;
    }

    /**
     * @return Media
     */
    public function getPortrait(): Media
    {
        return $this->portrait;
    }

    /**
     * @param Media $portrait
     */
    public function setPortrait(Media $portrait): void
    {
        $this->portrait = $portrait;
    }

    /**
     * @return Team
     */
    public function getTeam(): Team
    {
        return $this->team;
    }

    /**
     * @param Team $team
     */
    public function setTeam(Team $team): void
    {
        $this->team = $team;
    }
}