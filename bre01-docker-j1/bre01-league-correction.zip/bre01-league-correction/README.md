# bre01-league
Project for a a fake e-sport league using PHP, OOP and MVC

## Install

Install the vendors :

```sh
composer install 
```

## Prepare the autoload

```sh
composer dump-autoload
```

## Create database

You can find the tables for the project on the BRE01 session Discord Server.

## Set the environment variables

Make a copy of the `.env.example` file :

```sh
cp .env.example .env
```

Complete the variables for your database information in the newly created `.env` file.
