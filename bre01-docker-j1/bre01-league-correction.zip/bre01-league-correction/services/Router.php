<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class Router
{
    public function handleRequest(array $get) : void
    {
        $dc = new DefaultController();
        $tc = new TeamController();
        $pc = new PlayerController();
        $mc = new GameController();

        if(!isset($get["route"]))
        {
            $dc->home();
        }
        else if(isset($get["route"]) && isset($get["id"]) && $get["route"] === "teams")
        {
            $tc->team($get["id"]);
        }
        else if(isset($get["route"]) && $get["route"] === "teams")
        {
            $tc->teams();
        }
        else if(isset($get["route"]) && isset($get["id"]) && $get["route"] === "players")
        {
            $pc->player($get["id"]);
        }
        else if(isset($get["route"]) && $get["route"] === "players")
        {
            $pc->players();
        }
        else if(isset($get["route"]) && isset($get["id"]) && $get["route"] === "matches")
        {
            $mc->match($get["id"]);
        }
        else if(isset($get["route"]) && $get["route"] === "matches")
        {
            $mc->matches();
        }
    }
}