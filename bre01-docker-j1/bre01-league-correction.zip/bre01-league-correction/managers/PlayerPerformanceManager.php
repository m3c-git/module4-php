<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class PlayerPerformanceManager extends AbstractManager
{
    public function findByPlayer(int $playerId) : array
    {
        $gm = new GameManager();
        $pm = new PlayerManager();

        $query = $this->db->prepare('SELECT * FROM player_performance WHERE player=:id');
        $parameters = [
            "id" => $playerId
        ];
        $query->execute($parameters);
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        $perfs = [];

        foreach($result as $item)
        {
            $player = $pm->findOne($item["player"]);
            $game = $gm->findOne($item["game"]);
            $perf = new PlayerPerformance($player, $game, $item["points"], $item["assists"]);
            $perf->setId($item["id"]);
            $perfs[] = $perf;
        }

        return $perfs;
    }

    public function findByGame(int $gameId) : array
    {
        $gm = new GameManager();
        $pm = new PlayerManager();

        $query = $this->db->prepare('SELECT * FROM player_performance WHERE game=:id');
        $parameters = [
            "id" => $gameId
        ];
        $query->execute($parameters);
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        $perfs = [];

        foreach($result as $item)
        {
            $player = $pm->findOne($item["player"]);
            $game = $gm->findOne($item["game"]);
            $perf = new PlayerPerformance($player, $game, $item["points"], $item["assists"]);
            $perf->setId($item["id"]);
            $perfs[] = $perf;
        }

        return $perfs;
    }
}