<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class GameManager extends AbstractManager
{
    public function findOne(int $id)
    {
        $tm = new TeamManager();

        $query = $this->db->prepare('SELECT * FROM games WHERE id=:id');

        $parameters = [
            "id" => $id
        ];

        $query->execute($parameters);
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($result)
        {
            $team1 = $tm->findOne($result["team_1"]);
            $team2 = $tm->findOne($result["team_2"]);
            $winner = $tm->findOne($result["winner"]);

            $game = new Game($result["name"], DateTime::createFromFormat('Y-m-d H:i:s', $result["date"]), $team1, $team2, $winner);

            $game->setId($result["id"]);

            return $game;
        }

        return null;
    }

    public function findLatest()
    {
        $tm = new TeamManager();

        $query = $this->db->prepare('SELECT * FROM games ORDER BY date DESC LIMIT 1');

        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($result)
        {
            $team1 = $tm->findOne($result["team_1"]);
            $team2 = $tm->findOne($result["team_2"]);
            $winner = $tm->findOne($result["winner"]);

            $game = new Game($result["name"], DateTime::createFromFormat('Y-m-d H:i:s', $result["date"]), $team1, $team2, $winner);

            $game->setId($result["id"]);

            return $game;
        }

        return null;
    }

    public function findAll() : array
    {
        $tm = new TeamManager();

        $query = $this->db->prepare('SELECT * FROM games');
        $query->execute();
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        $games = [];

        foreach($result as $item)
        {
            $team1 = $tm->findOne($item["team_1"]);
            $team2 = $tm->findOne($item["team_2"]);
            $winner = $tm->findOne($item["winner"]);

            $game = new Game($item["name"], DateTime::createFromFormat('Y-m-d H:i:s', $item["date"]), $team1, $team2, $winner);

            $game->setId($item["id"]);

            $games[] = $game;
        }

        return $games;
    }
}