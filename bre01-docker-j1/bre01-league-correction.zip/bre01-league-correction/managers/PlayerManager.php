<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class PlayerManager extends AbstractManager
{
    public function findByTeam(int $teamId) : array
    {
        $mm = new MediaManager();
        $tm = new TeamManager();

        $query = $this->db->prepare('SELECT * FROM players WHERE team=:team');
        $parameters = [
            "team" => $teamId
        ];
        $query->execute($parameters);
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        $players = [];

        foreach($result as $item)
        {
            $portrait = $mm->findOne($item["portrait"]);
            $team = $tm->findOne($item["team"]);
            $player = new Player($item["nickname"], $item["bio"], $portrait, $team);
            $player->setId($item["id"]);
            $players[] = $player;
        }

        return $players;
    }

    public function findAll() : array
    {
        $mm = new MediaManager();
        $tm = new TeamManager();

        $query = $this->db->prepare('SELECT * FROM players ORDER BY nickname');
        $query->execute();
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        $players = [];

        foreach($result as $item)
        {
            $portrait = $mm->findOne($item["portrait"]);
            $team = $tm->findOne($item["team"]);
            $player = new Player($item["nickname"], $item["bio"], $portrait, $team);
            $player->setId($item["id"]);
            $players[] = $player;
        }

        return $players;
    }

    public function findOne(int $id) : ? Player
    {
        $mm = new MediaManager();
        $tm = new TeamManager();

        $query = $this->db->prepare('SELECT * FROM players WHERE id=:id');
        $parameters = [
            "id" => $id
        ];
        $query->execute($parameters);
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($result)
        {
            $portrait = $mm->findOne($result["portrait"]);
            $team = $tm->findOne($result["team"]);
            $player = new Player($result["nickname"], $result["bio"], $portrait, $team);
            $player->setId($result["id"]);
            return $player;
        }

        return null;
    }
}