<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class TeamManager extends AbstractManager
{
    public function findAll() : array
    {
        $mm = new MediaManager();

        $query = $this->db->prepare('SELECT * FROM teams');
        $query->execute();
        $result = $query->fetchAll(PDO::FETCH_ASSOC);
        $teams = [];

        foreach($result as $item)
        {
            $logo = $mm->findOne($item["logo"]);
            $team = new Team($item["name"], $item["description"], $logo);
            $team->setId($item["id"]);
            $teams[] = $team;
        }

        return $teams;
    }

    public function findOne(int $id) : ? Team
    {
        $mm = new MediaManager();

        $query = $this->db->prepare('SELECT * FROM teams WHERE id=:id');
        $parameters = [
            "id" => $id
        ];
        $query->execute($parameters);
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($result)
        {
            $logo = $mm->findOne($result["logo"]);
            $team = new Team($result["name"], $result["description"], $logo);
            $team->setId($result["id"]);

            return $team;
        }

        return null;
    }
}