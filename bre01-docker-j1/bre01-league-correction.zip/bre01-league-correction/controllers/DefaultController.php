<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class DefaultController extends AbstractController
{
    public function home()
    {
        $tm = new TeamManager();
        $pm = new PlayerManager();
        $gm = new GameManager();

        $teams = $tm->findAll();
        $key = array_rand($teams, 1);
        $team = [];
        $team["team"] = $teams[$key];
        $team["players"] = $pm->findByTeam($team["team"]->getId());

        $players = $pm->findAll();
        $keys = array_rand($players, 3);
        $featuredPlayers = [];

        foreach($keys as $key)
        {
            $featuredPlayers[] = $players[$key];
        }

        $this->render("home/home.html.twig", [
            "team" => $team,
            "players" => $featuredPlayers,
            "game" => $gm->findLatest()
        ]);
    }
}