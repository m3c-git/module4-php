<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class GameController extends AbstractController
{
    public function matches() : void
    {
        $gm = new GameManager();

        $games = $gm->findAll();

        $this->render("matches/matches.html.twig", [
            "games" => $games
        ]);
    }

    public function match(string $id) : void
    {
        $gm = new GameManager();
        $ppm = new PlayerPerformanceManager();

        $game = $gm->findOne(intval($id));
        $perfs = $ppm->findByGame(intval($id));

        $this->render("matches/match.html.twig", [
            "game" => $game,
            "perfs" => $perfs
        ]);
    }
}