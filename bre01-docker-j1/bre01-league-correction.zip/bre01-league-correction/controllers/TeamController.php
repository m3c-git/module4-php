<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class TeamController extends AbstractController
{
    public function team(string $id) : void
    {
        $tm = new TeamManager();
        $pm = new PlayerManager();

        $players = $pm->findByTeam(intval($id));
        $team = $tm->findOne(intval($id));

        $this->render("teams/team.html.twig", [
            "team" => $team,
            "players" => $players
        ]);
    }

    public function teams() : void
    {
        $tm = new TeamManager();
        $teams = $tm->findAll();

        $this->render("teams/teams.html.twig", [
            "teams" => $teams
        ]);
    }
}