<?php
/**
 * @author : Gaellan
 * @link : https://github.com/Gaellan
 */


class PlayerController extends AbstractController
{
    public function players() : void
    {
        $pm = new PlayerManager();
        $players = $pm->findAll();

        $this->render("players/players.html.twig", [
            "players" => $players
        ]);
    }

    public function player(string $id) : void
    {
        $pm = new PlayerManager();
        $ppm = new PlayerPerformanceManager();

        $player = $pm->findOne(intval($id));
        $players = $pm->findByTeam($player->getTeam()->getId());
        $perfs = $ppm->findByPlayer(intval($id));
        $this->render("players/player.html.twig", [
            "player" => $player,
            "players" => $players,
            "perfs" => $perfs
        ]);
    }
}